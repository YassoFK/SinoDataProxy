/********************************************************************************
** Form generated from reading UI file 'keydlg.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KEYDLG_H
#define UI_KEYDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_KeyDialog
{
public:
    QGridLayout *gridLayout;
    QLabel *Label9;
    QLabel *Label20;
    QLabel *Label3;
    QLabel *Label4;
    QLabel *Label5;
    QLabel *Label19;
    QLabel *Label16;
    QLabel *Label14;
    QLabel *Label6;
    QLabel *Label17;
    QLabel *Label12;
    QLabel *Label26;
    QLabel *Label30;
    QLabel *Label29;
    QLabel *Label36;
    QLabel *Label35;
    QLabel *Label24;
    QLabel *Label22;
    QPushButton *BtnOk;
    QLabel *Label34;
    QLabel *Label13;
    QLabel *Label31;
    QLabel *Label32;
    QLabel *Label25;
    QLabel *Label11;
    QLabel *Label23;
    QLabel *Label8;
    QLabel *Label2;
    QLabel *Label1;
    QLabel *Label27;
    QLabel *Label7;
    QLabel *Label18;
    QLabel *Label33;
    QLabel *Label28;
    QLabel *Label15;
    QLabel *Label10;
    QLabel *Label21;
    QLabel *Label37;
    QLabel *Label38;

    void setupUi(QWidget *KeyDialog)
    {
        if (KeyDialog->objectName().isEmpty())
            KeyDialog->setObjectName(QString::fromUtf8("KeyDialog"));
        KeyDialog->resize(639, 332);
        gridLayout = new QGridLayout(KeyDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        Label9 = new QLabel(KeyDialog);
        Label9->setObjectName(QString::fromUtf8("Label9"));
        Label9->setEnabled(true);

        gridLayout->addWidget(Label9, 1, 2, 1, 1);

        Label20 = new QLabel(KeyDialog);
        Label20->setObjectName(QString::fromUtf8("Label20"));
        Label20->setEnabled(true);

        gridLayout->addWidget(Label20, 1, 3, 1, 1);

        Label3 = new QLabel(KeyDialog);
        Label3->setObjectName(QString::fromUtf8("Label3"));
        Label3->setEnabled(true);

        gridLayout->addWidget(Label3, 2, 0, 1, 1);

        Label4 = new QLabel(KeyDialog);
        Label4->setObjectName(QString::fromUtf8("Label4"));
        Label4->setEnabled(true);

        gridLayout->addWidget(Label4, 3, 0, 1, 1);

        Label5 = new QLabel(KeyDialog);
        Label5->setObjectName(QString::fromUtf8("Label5"));
        Label5->setEnabled(true);

        gridLayout->addWidget(Label5, 4, 0, 1, 1);

        Label19 = new QLabel(KeyDialog);
        Label19->setObjectName(QString::fromUtf8("Label19"));
        Label19->setEnabled(true);

        gridLayout->addWidget(Label19, 0, 3, 1, 1);

        Label16 = new QLabel(KeyDialog);
        Label16->setObjectName(QString::fromUtf8("Label16"));
        Label16->setEnabled(true);

        gridLayout->addWidget(Label16, 4, 1, 1, 1);

        Label14 = new QLabel(KeyDialog);
        Label14->setObjectName(QString::fromUtf8("Label14"));
        Label14->setEnabled(true);

        gridLayout->addWidget(Label14, 2, 1, 1, 1);

        Label6 = new QLabel(KeyDialog);
        Label6->setObjectName(QString::fromUtf8("Label6"));
        Label6->setEnabled(true);

        gridLayout->addWidget(Label6, 5, 0, 1, 1);

        Label17 = new QLabel(KeyDialog);
        Label17->setObjectName(QString::fromUtf8("Label17"));
        Label17->setEnabled(true);

        gridLayout->addWidget(Label17, 5, 1, 1, 1);

        Label12 = new QLabel(KeyDialog);
        Label12->setObjectName(QString::fromUtf8("Label12"));
        Label12->setEnabled(true);

        gridLayout->addWidget(Label12, 0, 1, 1, 1);

        Label26 = new QLabel(KeyDialog);
        Label26->setObjectName(QString::fromUtf8("Label26"));
        Label26->setEnabled(true);

        gridLayout->addWidget(Label26, 5, 3, 1, 1);

        Label30 = new QLabel(KeyDialog);
        Label30->setObjectName(QString::fromUtf8("Label30"));
        Label30->setEnabled(true);

        gridLayout->addWidget(Label30, 7, 1, 1, 1);

        Label29 = new QLabel(KeyDialog);
        Label29->setObjectName(QString::fromUtf8("Label29"));
        Label29->setEnabled(true);

        gridLayout->addWidget(Label29, 7, 0, 1, 1);

        Label36 = new QLabel(KeyDialog);
        Label36->setObjectName(QString::fromUtf8("Label36"));
        Label36->setEnabled(true);

        gridLayout->addWidget(Label36, 8, 1, 1, 1);

        Label35 = new QLabel(KeyDialog);
        Label35->setObjectName(QString::fromUtf8("Label35"));
        Label35->setEnabled(true);

        gridLayout->addWidget(Label35, 8, 0, 1, 1);

        Label24 = new QLabel(KeyDialog);
        Label24->setObjectName(QString::fromUtf8("Label24"));
        Label24->setEnabled(true);

        gridLayout->addWidget(Label24, 4, 3, 1, 1);

        Label22 = new QLabel(KeyDialog);
        Label22->setObjectName(QString::fromUtf8("Label22"));
        Label22->setEnabled(true);

        gridLayout->addWidget(Label22, 3, 3, 1, 1);

        BtnOk = new QPushButton(KeyDialog);
        BtnOk->setObjectName(QString::fromUtf8("BtnOk"));
        BtnOk->setEnabled(true);
        BtnOk->setAutoDefault(true);

        gridLayout->addWidget(BtnOk, 9, 2, 1, 2);

        Label34 = new QLabel(KeyDialog);
        Label34->setObjectName(QString::fromUtf8("Label34"));
        Label34->setEnabled(true);

        gridLayout->addWidget(Label34, 9, 1, 1, 1);

        Label13 = new QLabel(KeyDialog);
        Label13->setObjectName(QString::fromUtf8("Label13"));
        Label13->setEnabled(true);

        gridLayout->addWidget(Label13, 1, 1, 1, 1);

        Label31 = new QLabel(KeyDialog);
        Label31->setObjectName(QString::fromUtf8("Label31"));
        Label31->setEnabled(true);

        gridLayout->addWidget(Label31, 8, 2, 1, 1);

        Label32 = new QLabel(KeyDialog);
        Label32->setObjectName(QString::fromUtf8("Label32"));
        Label32->setEnabled(true);

        gridLayout->addWidget(Label32, 8, 3, 1, 1);

        Label25 = new QLabel(KeyDialog);
        Label25->setObjectName(QString::fromUtf8("Label25"));
        Label25->setEnabled(true);

        gridLayout->addWidget(Label25, 5, 2, 1, 1);

        Label11 = new QLabel(KeyDialog);
        Label11->setObjectName(QString::fromUtf8("Label11"));
        Label11->setEnabled(true);

        gridLayout->addWidget(Label11, 3, 2, 1, 1);

        Label23 = new QLabel(KeyDialog);
        Label23->setObjectName(QString::fromUtf8("Label23"));
        Label23->setEnabled(true);

        gridLayout->addWidget(Label23, 4, 2, 1, 1);

        Label8 = new QLabel(KeyDialog);
        Label8->setObjectName(QString::fromUtf8("Label8"));
        Label8->setEnabled(true);

        gridLayout->addWidget(Label8, 0, 2, 1, 1);

        Label2 = new QLabel(KeyDialog);
        Label2->setObjectName(QString::fromUtf8("Label2"));
        Label2->setEnabled(true);

        gridLayout->addWidget(Label2, 1, 0, 1, 1);

        Label1 = new QLabel(KeyDialog);
        Label1->setObjectName(QString::fromUtf8("Label1"));
        Label1->setEnabled(true);

        gridLayout->addWidget(Label1, 0, 0, 1, 1);

        Label27 = new QLabel(KeyDialog);
        Label27->setObjectName(QString::fromUtf8("Label27"));
        Label27->setEnabled(true);

        gridLayout->addWidget(Label27, 6, 2, 1, 1);

        Label7 = new QLabel(KeyDialog);
        Label7->setObjectName(QString::fromUtf8("Label7"));
        Label7->setEnabled(true);

        gridLayout->addWidget(Label7, 6, 0, 1, 1);

        Label18 = new QLabel(KeyDialog);
        Label18->setObjectName(QString::fromUtf8("Label18"));
        Label18->setEnabled(true);

        gridLayout->addWidget(Label18, 6, 1, 1, 1);

        Label33 = new QLabel(KeyDialog);
        Label33->setObjectName(QString::fromUtf8("Label33"));
        Label33->setEnabled(true);

        gridLayout->addWidget(Label33, 9, 0, 1, 1);

        Label28 = new QLabel(KeyDialog);
        Label28->setObjectName(QString::fromUtf8("Label28"));
        Label28->setEnabled(true);

        gridLayout->addWidget(Label28, 6, 3, 1, 1);

        Label15 = new QLabel(KeyDialog);
        Label15->setObjectName(QString::fromUtf8("Label15"));
        Label15->setEnabled(true);

        gridLayout->addWidget(Label15, 3, 1, 1, 1);

        Label10 = new QLabel(KeyDialog);
        Label10->setObjectName(QString::fromUtf8("Label10"));
        Label10->setEnabled(true);

        gridLayout->addWidget(Label10, 2, 2, 1, 1);

        Label21 = new QLabel(KeyDialog);
        Label21->setObjectName(QString::fromUtf8("Label21"));
        Label21->setEnabled(true);

        gridLayout->addWidget(Label21, 2, 3, 1, 1);

        Label37 = new QLabel(KeyDialog);
        Label37->setObjectName(QString::fromUtf8("Label37"));
        Label37->setEnabled(true);

        gridLayout->addWidget(Label37, 7, 2, 1, 1);

        Label38 = new QLabel(KeyDialog);
        Label38->setObjectName(QString::fromUtf8("Label38"));
        Label38->setEnabled(true);

        gridLayout->addWidget(Label38, 7, 3, 1, 1);


        retranslateUi(KeyDialog);

        BtnOk->setDefault(true);


        QMetaObject::connectSlotsByName(KeyDialog);
    } // setupUi

    void retranslateUi(QWidget *KeyDialog)
    {
        KeyDialog->setWindowTitle(QCoreApplication::translate("KeyDialog", "Keyword Replacement in File Path", nullptr));
#if QT_CONFIG(tooltip)
        KeyDialog->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        Label9->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label9->setText(QCoreApplication::translate("KeyDialog", "%M", nullptr));
#if QT_CONFIG(tooltip)
        Label20->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label20->setText(QCoreApplication::translate("KeyDialog", ": Minute (00-59)", nullptr));
#if QT_CONFIG(tooltip)
        Label3->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label3->setText(QCoreApplication::translate("KeyDialog", "%m", nullptr));
#if QT_CONFIG(tooltip)
        Label4->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label4->setText(QCoreApplication::translate("KeyDialog", "%d", nullptr));
#if QT_CONFIG(tooltip)
        Label5->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label5->setText(QCoreApplication::translate("KeyDialog", "%n", nullptr));
#if QT_CONFIG(tooltip)
        Label19->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label19->setText(QCoreApplication::translate("KeyDialog", ": Hour (00-23)", nullptr));
#if QT_CONFIG(tooltip)
        Label16->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label16->setText(QCoreApplication::translate("KeyDialog", ": Day of Year (ddd)", nullptr));
#if QT_CONFIG(tooltip)
        Label14->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label14->setText(QCoreApplication::translate("KeyDialog", ": Month (mm)", nullptr));
#if QT_CONFIG(tooltip)
        Label6->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label6->setText(QCoreApplication::translate("KeyDialog", "%W", nullptr));
#if QT_CONFIG(tooltip)
        Label17->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label17->setText(QCoreApplication::translate("KeyDialog", ": GPS Week No (wwww)", nullptr));
#if QT_CONFIG(tooltip)
        Label12->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label12->setText(QCoreApplication::translate("KeyDialog", ": Year (yyyy)", nullptr));
#if QT_CONFIG(tooltip)
        Label26->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label26->setText(QCoreApplication::translate("KeyDialog", ": 6H Hour (00,06,12,18)", nullptr));
#if QT_CONFIG(tooltip)
        Label30->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label30->setText(QCoreApplication::translate("KeyDialog", ": Station ID", nullptr));
#if QT_CONFIG(tooltip)
        Label29->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label29->setText(QCoreApplication::translate("KeyDialog", "%r", nullptr));
#if QT_CONFIG(tooltip)
        Label36->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label36->setText(QCoreApplication::translate("KeyDialog", ": Station ID (UPPER case)", nullptr));
#if QT_CONFIG(tooltip)
        Label35->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label35->setText(QCoreApplication::translate("KeyDialog", "%S", nullptr));
#if QT_CONFIG(tooltip)
        Label24->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label24->setText(QCoreApplication::translate("KeyDialog", ": 3H Hour (00,03,...,21)", nullptr));
#if QT_CONFIG(tooltip)
        Label22->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label22->setText(QCoreApplication::translate("KeyDialog", ": Hour Code (a,b,...,x)", nullptr));
#if QT_CONFIG(tooltip)
        BtnOk->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        BtnOk->setText(QCoreApplication::translate("KeyDialog", "&OK", nullptr));
#if QT_CONFIG(tooltip)
        Label34->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label34->setText(QCoreApplication::translate("KeyDialog", ": Station ID (lower case)", nullptr));
#if QT_CONFIG(tooltip)
        Label13->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label13->setText(QCoreApplication::translate("KeyDialog", ": Year (yy)", nullptr));
#if QT_CONFIG(tooltip)
        Label31->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label31->setText(QCoreApplication::translate("KeyDialog", "%b", nullptr));
#if QT_CONFIG(tooltip)
        Label32->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label32->setText(QCoreApplication::translate("KeyDialog", ": Base Station ID", nullptr));
#if QT_CONFIG(tooltip)
        Label25->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label25->setText(QCoreApplication::translate("KeyDialog", "%hb", nullptr));
#if QT_CONFIG(tooltip)
        Label11->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label11->setText(QCoreApplication::translate("KeyDialog", "%H", nullptr));
#if QT_CONFIG(tooltip)
        Label23->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label23->setText(QCoreApplication::translate("KeyDialog", "%ha", nullptr));
#if QT_CONFIG(tooltip)
        Label8->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label8->setText(QCoreApplication::translate("KeyDialog", "%h", nullptr));
#if QT_CONFIG(tooltip)
        Label2->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label2->setText(QCoreApplication::translate("KeyDialog", "%y", nullptr));
#if QT_CONFIG(tooltip)
        Label1->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label1->setText(QCoreApplication::translate("KeyDialog", "%Y", nullptr));
#if QT_CONFIG(tooltip)
        Label27->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label27->setText(QCoreApplication::translate("KeyDialog", "%hc", nullptr));
#if QT_CONFIG(tooltip)
        Label7->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label7->setText(QCoreApplication::translate("KeyDialog", "%D", nullptr));
#if QT_CONFIG(tooltip)
        Label18->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label18->setText(QCoreApplication::translate("KeyDialog", ": Day of Week (0-6)", nullptr));
#if QT_CONFIG(tooltip)
        Label33->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label33->setText(QCoreApplication::translate("KeyDialog", "%s", nullptr));
#if QT_CONFIG(tooltip)
        Label28->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label28->setText(QCoreApplication::translate("KeyDialog", ": 12H Hour (00,12)", nullptr));
#if QT_CONFIG(tooltip)
        Label15->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label15->setText(QCoreApplication::translate("KeyDialog", ": Day of Month (dd)", nullptr));
#if QT_CONFIG(tooltip)
        Label10->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label10->setText(QCoreApplication::translate("KeyDialog", "%S", nullptr));
#if QT_CONFIG(tooltip)
        Label21->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label21->setText(QCoreApplication::translate("KeyDialog", ": Second (00:59)", nullptr));
#if QT_CONFIG(tooltip)
        Label37->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label37->setText(QCoreApplication::translate("KeyDialog", "%N", nullptr));
#if QT_CONFIG(tooltip)
        Label38->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        Label38->setText(QCoreApplication::translate("KeyDialog", ": Sequence Number", nullptr));
    } // retranslateUi

};

namespace Ui {
    class KeyDialog: public Ui_KeyDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KEYDLG_H
