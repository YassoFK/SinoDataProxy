/****************************************************************************
** Meta object code from reading C++ file 'svrmain.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../svrmain.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'svrmain.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainForm_t {
    QByteArrayData data[30];
    char stringdata0[424];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainForm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainForm_t qt_meta_stringdata_MainForm = {
    {
QT_MOC_LITERAL(0, 0, 8), // "MainForm"
QT_MOC_LITERAL(1, 9, 12), // "BtnExitClick"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 13), // "BtnInputClick"
QT_MOC_LITERAL(4, 37, 15), // "BtnOutput1Click"
QT_MOC_LITERAL(5, 53, 15), // "BtnOutput2Click"
QT_MOC_LITERAL(6, 69, 13), // "BtnStartClick"
QT_MOC_LITERAL(7, 83, 12), // "BtnStopClick"
QT_MOC_LITERAL(8, 96, 11), // "Timer1Timer"
QT_MOC_LITERAL(9, 108, 11), // "BtnOptClick"
QT_MOC_LITERAL(10, 120, 13), // "Output1Change"
QT_MOC_LITERAL(11, 134, 13), // "Output2Change"
QT_MOC_LITERAL(12, 148, 11), // "InputChange"
QT_MOC_LITERAL(13, 160, 15), // "BtnOutput3Click"
QT_MOC_LITERAL(14, 176, 13), // "Output3Change"
QT_MOC_LITERAL(15, 190, 11), // "BtnCmdClick"
QT_MOC_LITERAL(16, 202, 13), // "BtnAboutClick"
QT_MOC_LITERAL(17, 216, 14), // "BtnStrMonClick"
QT_MOC_LITERAL(18, 231, 11), // "Timer2Timer"
QT_MOC_LITERAL(19, 243, 16), // "BtnTaskIconClick"
QT_MOC_LITERAL(20, 260, 15), // "MenuExpandClick"
QT_MOC_LITERAL(21, 276, 17), // "TrayIconActivated"
QT_MOC_LITERAL(22, 294, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(23, 328, 14), // "MenuStartClick"
QT_MOC_LITERAL(24, 343, 13), // "MenuStopClick"
QT_MOC_LITERAL(25, 357, 13), // "MenuExitClick"
QT_MOC_LITERAL(26, 371, 10), // "FormCreate"
QT_MOC_LITERAL(27, 382, 13), // "BtnConv1Click"
QT_MOC_LITERAL(28, 396, 13), // "BtnConv2Click"
QT_MOC_LITERAL(29, 410, 13) // "BtnConv3Click"

    },
    "MainForm\0BtnExitClick\0\0BtnInputClick\0"
    "BtnOutput1Click\0BtnOutput2Click\0"
    "BtnStartClick\0BtnStopClick\0Timer1Timer\0"
    "BtnOptClick\0Output1Change\0Output2Change\0"
    "InputChange\0BtnOutput3Click\0Output3Change\0"
    "BtnCmdClick\0BtnAboutClick\0BtnStrMonClick\0"
    "Timer2Timer\0BtnTaskIconClick\0"
    "MenuExpandClick\0TrayIconActivated\0"
    "QSystemTrayIcon::ActivationReason\0"
    "MenuStartClick\0MenuStopClick\0MenuExitClick\0"
    "FormCreate\0BtnConv1Click\0BtnConv2Click\0"
    "BtnConv3Click"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainForm[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  149,    2, 0x0a /* Public */,
       3,    0,  150,    2, 0x0a /* Public */,
       4,    0,  151,    2, 0x0a /* Public */,
       5,    0,  152,    2, 0x0a /* Public */,
       6,    0,  153,    2, 0x0a /* Public */,
       7,    0,  154,    2, 0x0a /* Public */,
       8,    0,  155,    2, 0x0a /* Public */,
       9,    0,  156,    2, 0x0a /* Public */,
      10,    0,  157,    2, 0x0a /* Public */,
      11,    0,  158,    2, 0x0a /* Public */,
      12,    0,  159,    2, 0x0a /* Public */,
      13,    0,  160,    2, 0x0a /* Public */,
      14,    0,  161,    2, 0x0a /* Public */,
      15,    0,  162,    2, 0x0a /* Public */,
      16,    0,  163,    2, 0x0a /* Public */,
      17,    0,  164,    2, 0x0a /* Public */,
      18,    0,  165,    2, 0x0a /* Public */,
      19,    0,  166,    2, 0x0a /* Public */,
      20,    0,  167,    2, 0x0a /* Public */,
      21,    1,  168,    2, 0x0a /* Public */,
      23,    0,  171,    2, 0x0a /* Public */,
      24,    0,  172,    2, 0x0a /* Public */,
      25,    0,  173,    2, 0x0a /* Public */,
      26,    0,  174,    2, 0x0a /* Public */,
      27,    0,  175,    2, 0x0a /* Public */,
      28,    0,  176,    2, 0x0a /* Public */,
      29,    0,  177,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 22,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainForm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->BtnExitClick(); break;
        case 1: _t->BtnInputClick(); break;
        case 2: _t->BtnOutput1Click(); break;
        case 3: _t->BtnOutput2Click(); break;
        case 4: _t->BtnStartClick(); break;
        case 5: _t->BtnStopClick(); break;
        case 6: _t->Timer1Timer(); break;
        case 7: _t->BtnOptClick(); break;
        case 8: _t->Output1Change(); break;
        case 9: _t->Output2Change(); break;
        case 10: _t->InputChange(); break;
        case 11: _t->BtnOutput3Click(); break;
        case 12: _t->Output3Change(); break;
        case 13: _t->BtnCmdClick(); break;
        case 14: _t->BtnAboutClick(); break;
        case 15: _t->BtnStrMonClick(); break;
        case 16: _t->Timer2Timer(); break;
        case 17: _t->BtnTaskIconClick(); break;
        case 18: _t->MenuExpandClick(); break;
        case 19: _t->TrayIconActivated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 20: _t->MenuStartClick(); break;
        case 21: _t->MenuStopClick(); break;
        case 22: _t->MenuExitClick(); break;
        case 23: _t->FormCreate(); break;
        case 24: _t->BtnConv1Click(); break;
        case 25: _t->BtnConv2Click(); break;
        case 26: _t->BtnConv3Click(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainForm::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_MainForm.data,
    qt_meta_data_MainForm,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainForm.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int MainForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
